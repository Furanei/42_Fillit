
#include "libft.h"

int main()
{
	char *titi;
	char toto[] = "toto aime les chips";
	titi = ft_insert_point(toto);
	printf("insert point :%s\n", titi);
	//printf("%s\n", toto);
	titi = ft_first_upper(titi);
	printf("first upper :%s\n", titi);
	titi = ft_all_tolower(titi);
	printf("all lower :%s\n", titi);

}